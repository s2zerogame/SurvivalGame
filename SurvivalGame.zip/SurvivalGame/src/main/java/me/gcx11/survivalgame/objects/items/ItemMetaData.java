package me.gcx11.survivalgame.objects.items;

/**
 * Created on 14.5.2017.
 */
public abstract class ItemMetaData {

}
