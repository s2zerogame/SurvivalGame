/**
 * Package contains game object subclasses mainly related to items
 * and also contains some other item related classes like recipes and inventories.
 */
package me.gcx11.survivalgame.objects;