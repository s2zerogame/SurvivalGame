package me.gcx11.survivalgame.world.generator;

/**
 * Created on 27.4.2017.
 */
public enum BiomeType {

    FOREST, DESERT, PLAINS
}
