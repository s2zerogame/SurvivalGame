package me.gcx11.survivalgame.api.plugins;

/**
 * Created on 29.8.2017.
 */
public abstract class ManagerBase {

    /**
     * Unloads plugin data.
     * @param plugin plugin
     */
    public abstract void unloadPlugin(Plugin plugin);
}
