package me.gcx11.survivalgame.api.events;

import java.lang.annotation.*;

/**
 * Created on 3.9.2017.
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface EventHandler {
}
