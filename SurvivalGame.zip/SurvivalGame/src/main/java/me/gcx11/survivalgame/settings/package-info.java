/**
 * Package contains structures for storing game settings.
 */
package me.gcx11.survivalgame.settings;