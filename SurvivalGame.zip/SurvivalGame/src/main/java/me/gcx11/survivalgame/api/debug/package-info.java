/**
 * Package for some game debug objects.
 */
package me.gcx11.survivalgame.api.debug;