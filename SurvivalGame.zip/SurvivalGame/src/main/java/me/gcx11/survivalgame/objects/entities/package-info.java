/**
 * Package contains class related to in-game entities.
 */
package me.gcx11.survivalgame.objects.entities;