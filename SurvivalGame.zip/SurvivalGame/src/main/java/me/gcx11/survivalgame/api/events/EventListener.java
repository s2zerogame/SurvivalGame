package me.gcx11.survivalgame.api.events;

/**
 * Created on 3.9.2017.
 */
public interface EventListener {
}
