/**
 * Package contains definitions of recipes.
 */
package me.gcx11.survivalgame.objects.recipes;