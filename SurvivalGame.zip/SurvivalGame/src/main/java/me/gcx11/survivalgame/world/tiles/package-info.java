/**
 * Package contains game tiles used as ground textures.
 */
package me.gcx11.survivalgame.world.tiles;